package com.capgemini.test.service;


import java.util.List;

import com.capgemini.test.entities.Product;
import com.capgemini.test.exception.ProductException;

public interface IProductService 
{
	public Product removeProduct(int id) throws ProductException;

	public List<Product> getAllProducts() throws ProductException;
	
	
}

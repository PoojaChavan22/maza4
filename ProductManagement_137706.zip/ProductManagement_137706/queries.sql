
drop table Product cascade constraints;

Create Table Product(
product_id number(5) primary key,
product_name varchar2(30),
product_price Number(10),
product_quantity number(5),
description varchar2(40)
);
insert into Product values (1001,'iPhone',45000,10,'Electronics Equipment From Apple');
insert into Product values (1002,'Cartoon Shirt',345,15,'Kids wear 4 to 12 Years');
insert into Product values (1003,'Sofa',20000,12,'HouseHold Furnitures');

commit;

select * from Product;
